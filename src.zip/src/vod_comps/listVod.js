import React,{useContext} from 'react';
import { arcontext } from '../context/arcontext';
import ItemVod from './itemVod';
import InputVod from './inputVod';

function ListVod(props){
    let {ar,setAr}  = useContext(arcontext)
    
    
    return(
        <div className='container'>
          <InputVod/>
        <div className="row">
          {ar.map(item => {
            return (
             <ItemVod key={item.imdbID} item={item}/>
            )
          })}
        </div>
      </div>
    )
}

export default ListVod